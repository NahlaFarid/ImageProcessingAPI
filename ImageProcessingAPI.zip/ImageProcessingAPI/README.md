# Image Processing API

## Endpoint

### `/api/image/resize?width=<width>&height=<height>&filename=<image_name>`

Method: `get`
URL Params: `height` and `width` - the height or width of the image in pixels
Query Param: `filename` - the specific image you are requesting, it must contain the image extension and can accept images with any extension.

    For example: `localhost:3000/api/image/resize?width=300&height=300&filename=icelandwaterfall.jpg`

#### Available Image options

1. `encenadaport.jpg`
2. `fjord.jpg`
3. `icelandwaterfall.jpg`
4. `palmtunnel.jpg`
5. `santamonica.jpg`
6. `butterfly.jpg`
7. `maddy.jpg`
8. `mobile.png`
9. `oren.jpg`
10. `swan.jpg`
11. `window.jpg`

## Scripts

`npm start` Start the server with nodemon
`npm run test` To run tests
`npm run build` To build application
`npm run prettier` To format code
`npm run lint` To validate eslint

### References

For endpoint parameters Validation : [express-validator](https://express-validator.github.io/docs/index.html)
For getting image extension : [stackoverflow](https://stackoverflow.com/questions/10865347/node-js-get-file-extension)
Middleware to enable case insensitive querystring : [stackoverflow](https://stackoverflow.com/questions/15521876/nodejs-express-is-it-possible-to-have-case-insensitive-querystring)
